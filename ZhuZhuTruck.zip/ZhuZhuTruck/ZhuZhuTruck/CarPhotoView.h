//
//  CarPhotoView.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/25.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarPhotoView : UIView
- (void)setTitle:(NSString *)title andPhotoName:(NSString *)photoName;
@end
