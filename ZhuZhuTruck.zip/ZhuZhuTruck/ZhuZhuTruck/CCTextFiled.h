//
//  CCTextFiled.h
//  ZhengChe
//
//  Created by CongCong on 16/9/12.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCTextFiled : UITextField
- (id)initWithFrame:(CGRect)frame;
- (void)setLeftImg:(UIImageView*)imgView;
@end
