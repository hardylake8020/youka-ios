//
//  DeliveryContactsModel.m
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/8.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import "DeliveryContactsModel.h"

@implementation DeliveryContactsModel

@end
