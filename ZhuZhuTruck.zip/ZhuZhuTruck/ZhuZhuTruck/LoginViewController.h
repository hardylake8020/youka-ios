//
//  LoginViewController.h
//  ZhengChe
//
//  Created by CongCong on 16/9/12.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController
@property (nonatomic, assign) BOOL isAutoLogin;
@end
