//
//  WalletCell.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/4.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WalletCell : UITableViewCell
- (void)showCellWithDataDict:(NSDictionary *)dataDict;
@end
