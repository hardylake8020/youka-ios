//
//  PhotosCell.h
//  ZhengChe
//
//  Created by CongCong on 16/9/18.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotosCell : UICollectionViewCell
- (void)setTitle:(NSString *)title andPhotoName:(NSString *)photoName;
@end
