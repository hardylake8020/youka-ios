//
//  TenderProcessCell.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/3.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TenderModel.h"
@interface TenderProcessCell : UITableViewCell
- (void)showTenderCellWithTenderModel:(TenderModel *)model;
@end
