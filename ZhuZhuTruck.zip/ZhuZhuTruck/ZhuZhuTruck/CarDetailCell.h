//
//  CarDetailCell.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/6.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TruckDetailCellModel.h"
@interface CarDetailCell : UITableViewCell
- (void)showCellWithCellModel:(TruckDetailCellModel *)model;
@end
