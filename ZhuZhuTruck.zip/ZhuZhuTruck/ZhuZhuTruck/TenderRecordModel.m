//
//  TenderRecordModel.m
//  ZhuZhuTruck
//
//  Created by CongCong on 2017/2/11.
//  Copyright © 2017年 CongCong. All rights reserved.
//

#import "TenderRecordModel.h"

@implementation TenderRecordModel

@end
