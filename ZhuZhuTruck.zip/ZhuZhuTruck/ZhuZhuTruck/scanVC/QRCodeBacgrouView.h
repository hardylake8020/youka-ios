//
//  QRCodeBacgrouView.h
//  shikeApp
//
//  Created by 淘发现4 on 16/1/7.
//  Copyright © 2016年 淘发现1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRCodeBacgrouView : UIView
@property(nonatomic,assign)CGRect scanFrame;
@end
