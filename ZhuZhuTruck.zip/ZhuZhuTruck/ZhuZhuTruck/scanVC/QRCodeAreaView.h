//
//  QRCodeAreaView.h
//  shikeApp
//
//  Created by 淘发现4 on 16/1/7.
//  Copyright © 2016年 淘发现1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRCodeAreaView : UIView
/**
 *  开始动画
 */
-(void)startAnimaion;

/**
 *  暂停动画
 */
-(void)stopAnimaion;
@end
