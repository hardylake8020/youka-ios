//
//  PersonInfoViewController.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2017/3/3.
//  Copyright © 2017年 CongCong. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonInfoViewController : BaseViewController

@end
