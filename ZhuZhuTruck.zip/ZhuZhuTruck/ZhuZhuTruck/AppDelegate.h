//
//  AppDelegate.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/11/29.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
+ (AppDelegate *)shareAppDelegate;
@property (strong, nonatomic) UIWindow *window;


@end

