//
//  ErrorMaskView.h
//  ZhengChe
//
//  Created by CongCong on 16/9/25.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ErrorMaskView : UIView
@property (nonatomic, strong)UILabel *messageLabel;
@property (nonatomic, strong)UIImageView *imageView;
@end
