//
//  NSMutableArray+Tool.h
//  shunshouzhuanqian
//
//  Created by CongCong on 16/4/5.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (Tool)
-(BOOL)isEmpty;
-(void) addDict:(NSMutableDictionary*) dict;
@end
