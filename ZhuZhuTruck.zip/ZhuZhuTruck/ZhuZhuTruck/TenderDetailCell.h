//
//  TenderDetailCell.h
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/4.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TenderDetailCellModel.h"
@interface TenderDetailCell : UITableViewCell
- (void)showCellWithModel:(TenderDetailCellModel*)model;
@end
