//
//  DriverModel.m
//  ZhuZhuTruck
//
//  Created by CongCong on 2017/3/19.
//  Copyright © 2017年 CongCong. All rights reserved.
//

#import "DriverModel.h"

@implementation DriverModel

@end
