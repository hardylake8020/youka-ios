//
//  TruckBindCardModel.m
//  ZhuZhuTruck
//
//  Created by CongCong on 2016/12/25.
//  Copyright © 2016年 CongCong. All rights reserved.
//

#import "TruckBindCardModel.h"

@implementation TruckBindCardModel

@end
